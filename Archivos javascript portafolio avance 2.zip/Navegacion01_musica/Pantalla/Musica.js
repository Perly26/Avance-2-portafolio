//Macarena Almonacid
//Portafolio Navegación 2
import React, { useState } from 'react';
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, Image, Pressable } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Icon from 'react-native-vector-icons/FontAwesome';

export default function App() {
  // Estado para el color del icono del corazón
  const [isLiked, setIsLiked] = useState(false);

  // Función para alternar el color del corazón
  const toggleHeart = () => {
    setIsLiked(!isLiked);
  };

  return (
    <LinearGradient
      colors={['#ffe8b3', '#ebf3a5', '#cef3a5', '#ddffb7']}
      style={styles.container}
    >
      <View style={styles.containerimgtexto}>
        <Image
          source={{
            uri: 'https://diariosocialrd.com/wp-content/uploads/2018/10/isabelle-valdez-final-e1539567323938.jpg',
          }}
          style={styles.image}
        />
        <Text style={styles.text}>En Victoria Yo Estoy</Text>
        <Text style={styles.text2}>Isabelle Valdez</Text>
        <StatusBar style="auto" />
      </View>

      <View style={styles.containerbotones}>
        {/* Icono de corazón con cambio de color */}
        <Pressable
          onPress={toggleHeart}
          style={({ pressed }) => [
            styles.button1,
            { backgroundColor: 'transparent' },
          ]}
        >
          <Icon name="heart" size={34} color={isLiked ? '#808080' : '#FF0000'} />
        </Pressable>

        {/* Otros botones */}
        <View style={styles.buttonContainer}>
          <Pressable
            onPress={() => {}}
            style={({ pressed }) => [
              styles.button,
              { backgroundColor: 'transparent' },
            ]}
          >
            <Icon name="backward" size={34} color="#000000" />
          </Pressable>

          <Pressable
            onPress={() => {}}
            style={({ pressed }) => [
              styles.button,
              { backgroundColor: 'transparent' },
            ]}
          >
            <Icon name="play-circle" size={34} color="#000000" />
          </Pressable>

          <Pressable
            onPress={() => {}}
            style={({ pressed }) => [
              styles.button,
              { backgroundColor: 'transparent' },
            ]}
          >
            <Icon name="forward" size={34} color="#000000" />
          </Pressable>
        </View>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  containerimgtexto: {
    flex: 3,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 4, height: 4 },
    shadowOpacity: 0.5,
    shadowRadius: 10,
    elevation: 5,
  },
  containerbotones: {
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'center',
    paddingBottom: 60, // Ajusta este valor para elevar los botones
  },
  text: {
    color: '#000000',
    fontSize: 20,
    fontWeight: '600',
    marginTop: 10,
  },
  text2: {
    color: '#aba7a7',
    fontSize: 20,
    fontWeight: '300',
  },
  image: {
    width: 300,
    height: 300,
    borderRadius: 10,
    marginBottom: 20,
   },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginBottom: 50, // Ajusta este valor para subir o bajar el grupo de botones
  },
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 20,
    borderRadius: 20,
    marginHorizontal: 6,
  },
  button1: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 80,
    borderRadius: 20,
    marginHorizontal: 8,
  },
});
