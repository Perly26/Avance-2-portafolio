import React from 'react';
import { View, Text, Pressable, StyleSheet } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';

export default function Principal({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Seleccione una opción</Text>
      <View style={styles.buttonContainer}>
        {/* Botón Home */}
        <View>
          <Pressable
            onPress={() => navigation.navigate('Home')}
            style={({ pressed }) => [
              styles.button,
              { backgroundColor: pressed ? '#ffc107' : '#ff9800' },
            ]}
          >
            <Icon name="home" size={80} color="white" />
          </Pressable>
          <Text style={styles.buttonText}>Home</Text>
        </View>

        {/* Botón Settings */}
        <View style={styles.iconContainer}>
          <Pressable
            onPress={() => navigation.navigate('Settings')}
            style={({ pressed }) => [
              styles.button,
              { backgroundColor: pressed ? '#00acc1' : '#00bcd4' },
            ]}
          >
            <Icon name="cog" size={80} color="white" />
          </Pressable>
          <Text style={styles.buttonText}>Settings</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5', // Fondo sólido sin gradiente
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginBottom: 60,
  },
  button: {
    justifyContent: 'center',
    alignItems: 'center',
    padding: 10,
    borderRadius: 60,
    marginHorizontal: 36,
    width: 100,
    height: 100,
  },
  iconContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonText: {
    marginTop: 6, // Separación del texto respecto al botón
    color: '#000000',
    textAlign: 'center',
  },
});
