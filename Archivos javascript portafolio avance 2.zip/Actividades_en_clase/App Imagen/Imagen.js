//Macarena Almonacid
//Imágenes
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, Image } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

export default function App() {
  return (
    <LinearGradient
      colors={['#ffe8b3', '#ebf3a5', '#cef3a5', '#ddffb7']}
      style={styles.container}
    >
      <View style={styles.container}>
        <Image 
          source={require('./assets/LOGO_ORIGINAL_TRANSPARENCIA.png')}
          style={styles.imagen} 
        />
        
        <Text style={styles.text}>Bienvenidos a la aplicación de puntos verdes propuesta por la municipalidad de Quinchao</Text>
        
        <Text style={styles.text2}>Municipalidad de Quinchao</Text>
        <StatusBar style="auto" />

        <View style={styles.imageContainer}>
          <Image 
            source={{ uri: 'https://goctechnology.com/images/btn_g_login.png' }}
            style={styles.imagenuri} 
          />
        </View>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },

  text: {
    color: '#000000',
    fontSize: 20,
    fontWeight: '600',
    textAlign: 'center', 
    marginHorizontal: 20, 
    marginBottom: 20,
  },

  text2: {
    color: '#000000',
    fontSize: 20,
    fontWeight: '350',
    textAlign: 'center',
    marginBottom: 40,
  },

  imagen: {
    width: 180,
    height: 200,
    borderRadius: 10,
    marginBottom: 20,
  },

  imageContainer: {
    marginTop: 60, 
  },
  
  imagenuri: {
    width: 290,
    height: 60,
    borderRadius: 10,
    marginBottom: 40,
  },
});
