//Macarena Almonacid
//Etiquetas, Actividad de View y Text.
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

export default function App() {
  return (
    <LinearGradient
      colors={['#ffe8b3','#ebf3a5', '#cef3a5', '#ddffb7']}
      style={styles.container}>
        
      <View style={styles.container}>
        <Text style={styles.text}>Bienvenidos a la aplicación de puntos verdes propuesta por la municipalidad de Quinchao</Text>
        <StatusBar style="auto" />
        </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },

  text: {
    color: '#000000',
    fontSize: 20,
    fontWeight: '600',
 },


});
