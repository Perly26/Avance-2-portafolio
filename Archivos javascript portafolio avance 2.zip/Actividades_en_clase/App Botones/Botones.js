//Macarena Almonacid
//Botonoes
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, Image, Button, Pressable, TouchableHighlight, Alert } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Icon from 'react-native-vector-icons/FontAwesome';

export default function App() {
  return (
    <LinearGradient
      colors={['#ffe8b3', '#ebf3a5', '#cef3a5', '#ddffb7']}
      style={styles.container}
    >
      {/* Imagen del logo municipalidad Quinchao y texto */}
      <View style={styles.container}>
        <Image 
          source={require('./assets/LOGO_ORIGINAL_TRANSPARENCIA.png')}
          style={styles.imagen} 
        />
        <Text style={styles.text}>Bienvenidos a la aplicación de puntos verdes propuesta por la municipalidad de Quinchao</Text>
        <Text style={styles.text2}>Municipalidad de Quinchao</Text>
        <StatusBar style="auto" />
        {/* Botones los 3 tipos vistos en clase */}
        <View style={styles.buttonContainer}>
          <Button
            title="   PULSA AQUÍ   "
            color="#a5d6a7"
            onPress={() => Alert.alert('Botón 1')}
          />

          <TouchableHighlight
            onPress={() => Alert.alert('presiona aquí')}
            underlayColor="#aed581"
            style={styles.button2}
          >
            <Text style={styles.buttonText2}>Presiona Aquí</Text>
          </TouchableHighlight>

          <Pressable
            onPress={() => Alert.alert('Enviar')}
            style={({ pressed }) => [
              styles.boton3,
              { backgroundColor: pressed ? '#a5d6a7' : '#8bc34a' },
            ]}
          >
            {/* Icono google */}
            <Icon name="google" size={20} color="#B22222" style={styles.googleIcon} />
            <Text style={styles.buttonText}>Enviar</Text>
          </Pressable>
        </View>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },

  text: {
    color: '#000000',
    fontSize: 20,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 20,
  },

  text2: {
    color: '#000000',
    fontSize: 20,
    fontWeight: '350',
    textAlign: 'center',
    marginBottom: 40,
  },

  imagen: {
    width: 180,
    height: 200,
    borderRadius: 10,
    marginBottom: 40,
  },

  buttonContainer: {
    marginTop: 30,
    alignItems: 'center',
  },

  button2: {
    padding:10,
    backgroundColor: '#aed581',
    borderRadius: 8,
    marginTop: 8,
    width: 120,
    paddingVertical: 10,
    alignItems: 'center',
  },

  buttonText2: {
    color: '#ffffff',
    fontWeight: '600',
  },

  boton3: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
    borderRadius: 10,
    marginTop: 8,
    backgroundColor: '#8bc34a',
    width: 120,
    paddingVertical: 10,
  },

  googleIcon: {
    marginRight: 8,
  },

  buttonText: {
    color: '#B22222',
    fontWeight: '600',
  },
});
