//Macarena Almonacid
//Segunda pantalla de navegación
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

export default function App() {
    return (
        <LinearGradient
        colors={['#ffe8b3','#ebf3a5', '#cef3a5', '#ddffb7']}
        style={styles.container}>
          
        <View style={styles.container}>
          <Text style={styles.text}>Segunda pantalla de la aplicación puntos verdes</Text>
          <StatusBar style="auto" />
          </View>
      </LinearGradient>
    );
  }

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
    },
  
    text: {
      color: '#000000',
      fontSize: 20,
      fontWeight: '600',
   },
  
  
  });