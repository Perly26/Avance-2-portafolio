//Macarena Almonacid
//Navegación
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, Image, Button, Pressable, Alert } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Icon from 'react-native-vector-icons/FontAwesome';


export default function App() {
  return (
    <LinearGradient
      colors={['#ffe8b3','#ebf3a5', '#cef3a5', '#ddffb7']}
      style={styles.container}
    >
      <View style={styles.container}>
        <Image source={require('/Actividades en clase/prueba/assets/LOGO_ORIGINAL_TRANSPARENCIA.png')}
        style={styles.imagen} />
        <Text style={styles.text}>Bienvenidos a la aplicación de puntos verdes propuesta por la municipalidad de Quinchao</Text>
        <Text style={styles.text2}>Municipalidad de Quinchao</Text>
        <StatusBar style="auto" />
        {/* Botones de alerta */}
        <View>
          <Pressable
            onPress={() => Alert.alert('Enviar')}
            style={({ pressed }) => [
              styles.boton3,
              { backgroundColor: pressed ? '#42ff00' : '#b6ff00' }
            ]}
          >
            <Icon name="google" size={20} color="#B22222" style={styles.googleIcon} />
            <Text style={styles.buttonText}>Iniciar Sesión</Text>
          </Pressable>
        </View>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
    container: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
    },
  
    text: {
      color: '#000000',
      fontSize: 20,
      fontWeight: '600',
    },
  
    text2: {
      color: '#000000',
      fontSize: 20,
      fontWeight: '350',
    },
  
    imagen: {
      width: 300,
      height: 300,
      borderRadius: 10,
      marginBottom: 20,
    },
  botton3: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
    borderRadius: 20,
    marginTop: 10,
  },

  googleIcon: {
    marginRight: 8,
  },

  buttonText: {
    color: '#B22222',
    fontWeight: '600',
  },
});
