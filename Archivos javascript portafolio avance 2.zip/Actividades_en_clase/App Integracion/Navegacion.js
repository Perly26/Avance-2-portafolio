// Macarena Almonacid
// Pantalla con Imágenes y Botones
import React from 'react';
import { StyleSheet, Text, View, Image, Button, Pressable, TouchableHighlight, Alert } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Icon from 'react-native-vector-icons/FontAwesome';

export default function Navegacion({ navigation }) {
  return (
    <LinearGradient
      colors={['#ffe8b3', '#ebf3a5', '#cef3a5', '#ddffb7']}
      style={styles.container}
    >
      <View style={styles.container}>
        {/* Imagen del logo desde assets */}
        <Image 
          source={require('../assets/LOGO_ORIGINAL_TRANSPARENCIA.png')} 
          style={styles.imagen} 
        />

        {/* Texto */}
        <Text style={styles.text}>
          Bienvenidos a la aplicación de puntos verdes propuesta por la municipalidad de Quinchao
        </Text>
        <Text style={styles.text2}>Municipalidad de Quinchao</Text>

        {/* Botones 3 tipos*/}
        <View style={styles.buttonContainer}>
          <View style={styles.button1}>
          <Button
            title="PULSA AQUÍ"
            color="#54c240"
            onPress={() => Alert.alert('Alerta sobre botón presionado')}
          />
          </View>

          <TouchableHighlight
            onPress={() => Alert.alert('Alerta sobre botón presionado')}
            underlayColor="#aed581"
            style={styles.button2}
          >
            <Text style={styles.buttonText2}>Presiona Aquí</Text>
          </TouchableHighlight>
        {/* al presionar el botón llevará a una segunda pantalla */}
          <Pressable
            onPress={() =>  navigation.navigate('SegundaPantalla')}
            style={({ pressed }) => [
              styles.boton3,
              { backgroundColor: pressed ? '#42ff00' : '#b6ff00' },
            ]}
          >
            <Icon name="google" size={20} color="#B22222" style={styles.googleIcon} />
            <Text style={styles.buttonText}>Iniciar Sesión</Text>
          </Pressable>
        </View>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  text: {
    color: '#000000',
    fontSize: 20,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 20,
  },
  text2: {
    color: '#000000',
    fontSize: 18,
    fontWeight: '350',
    textAlign: 'center',
    marginBottom: 30,
  },
  imagen: {
    width: 180,
    height: 200,
    borderRadius: 10,
    marginBottom: 30,
  },
  buttonContainer: {
    marginTop: 30,
    alignItems: 'center',
  },
  button1: {
    width: 140,
  },
  button2: {
    padding: 10,
    backgroundColor: '#4cd334',
    borderRadius: 8,
    marginTop: 15,
    width: 140,
    alignItems: 'center',
  },
  buttonText2: {
    color: '#ffffff',
    fontWeight: '600',
  },
  boton3: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
    borderRadius: 10,
    marginTop: 15,
    width: 140,
    justifyContent: 'center',
  },
  googleIcon: {
    marginRight: 8,
  },
  buttonText: {
    color: '#B22222',
    fontWeight: '600',
  },
});
