// Macarena Almonacid
// Navegación
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Navegacion from './App Integracion/Navegacion';
import SegundaPantalla from './App Navegación/SegundaPantalla';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{headerShown: false}}>
        <Stack.Screen name="Navegacion" component={Navegacion}/>
        <Stack.Screen name="SegundaPantalla" component={SegundaPantalla}/>
      </Stack.Navigator>
    </NavigationContainer>
  );
}
